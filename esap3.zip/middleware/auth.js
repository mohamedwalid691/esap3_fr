export default function (context) {
  const token = localStorage.getItem("token");
  if (!context.store.state.isAuth) {
    if (token) {
      return context.store.dispatch("autoLogin");

    } else {
      context.redirect({
        name: 'login'
      })
    }




  } else {

  }
}
