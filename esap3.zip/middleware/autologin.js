export default function (context) {
  const token = localStorage.getItem("token");
  if (context.store.state.isAuth) {

  } else if (!context.store.state.isAuth) {
    if (token) {
      return context.store.dispatch("autoLogin");

    }



  } else {

  }
}
