export default function (context) {
    context.redirect("/admin/dashboard");
  }