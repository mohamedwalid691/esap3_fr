import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const VUEX_PROPERTIES = ['state', 'getters', 'actions', 'mutations']

let store = {};

(function updateModules () {
  store = normalizeRoot(require('..\\store\\index.js'), 'store/index.js')

  // If store is an exported method = classic mode (deprecated)

  // Enforce store modules
  store.modules = store.modules || {}

  resolveStoreModules(require('..\\store\\modules\\user\\index.js'), 'modules/user/index.js')
  resolveStoreModules(require('..\\store\\modules\\subcategory\\index.js'), 'modules/subcategory/index.js')
  resolveStoreModules(require('..\\store\\modules\\slider\\index.js'), 'modules/slider/index.js')
  resolveStoreModules(require('..\\store\\modules\\reusable\\index.js'), 'modules/reusable/index.js')
  resolveStoreModules(require('..\\store\\modules\\product\\index.js'), 'modules/product/index.js')
  resolveStoreModules(require('..\\store\\modules\\order\\index.js'), 'modules/order/index.js')
  resolveStoreModules(require('..\\store\\modules\\coupon\\index.js'), 'modules/coupon/index.js')
  resolveStoreModules(require('..\\store\\modules\\category\\index.js'), 'modules/category/index.js')
  resolveStoreModules(require('..\\store\\modules\\category\\actions.js'), 'modules/category/actions.js')
  resolveStoreModules(require('..\\store\\modules\\category\\getter.js'), 'modules/category/getter.js')
  resolveStoreModules(require('..\\store\\modules\\category\\mutations.js'), 'modules/category/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\coupon\\actions.js'), 'modules/coupon/actions.js')
  resolveStoreModules(require('..\\store\\modules\\coupon\\getter.js'), 'modules/coupon/getter.js')
  resolveStoreModules(require('..\\store\\modules\\coupon\\mutations.js'), 'modules/coupon/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\order\\actions.js'), 'modules/order/actions.js')
  resolveStoreModules(require('..\\store\\modules\\order\\getter.js'), 'modules/order/getter.js')
  resolveStoreModules(require('..\\store\\modules\\order\\mutations.js'), 'modules/order/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\product\\actions.js'), 'modules/product/actions.js')
  resolveStoreModules(require('..\\store\\modules\\product\\getter.js'), 'modules/product/getter.js')
  resolveStoreModules(require('..\\store\\modules\\product\\mutations.js'), 'modules/product/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\reusable\\actions.js'), 'modules/reusable/actions.js')
  resolveStoreModules(require('..\\store\\modules\\reusable\\getter.js'), 'modules/reusable/getter.js')
  resolveStoreModules(require('..\\store\\modules\\reusable\\mutations.js'), 'modules/reusable/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\slider\\actions.js'), 'modules/slider/actions.js')
  resolveStoreModules(require('..\\store\\modules\\slider\\getter.js'), 'modules/slider/getter.js')
  resolveStoreModules(require('..\\store\\modules\\slider\\mutations.js'), 'modules/slider/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\subcategory\\actions.js'), 'modules/subcategory/actions.js')
  resolveStoreModules(require('..\\store\\modules\\subcategory\\getter.js'), 'modules/subcategory/getter.js')
  resolveStoreModules(require('..\\store\\modules\\subcategory\\mutations.js'), 'modules/subcategory/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\user\\actions.js'), 'modules/user/actions.js')
  resolveStoreModules(require('..\\store\\modules\\user\\getter.js'), 'modules/user/getter.js')
  resolveStoreModules(require('..\\store\\modules\\user\\mutations.js'), 'modules/user/mutations.js')

  // If the environment supports hot reloading...
})()

// createStore
export const createStore = store instanceof Function ? store : () => {
  return new Vuex.Store(Object.assign({
    strict: (process.env.NODE_ENV !== 'production')
  }, store))
}

function normalizeRoot (moduleData, filePath) {
  moduleData = moduleData.default || moduleData

  if (moduleData.commit) {
    throw new Error(`[nuxt] ${filePath} should export a method that returns a Vuex instance.`)
  }

  if (typeof moduleData !== 'function') {
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData)
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeModule (moduleData, filePath) {
  if (moduleData.state && typeof moduleData.state !== 'function') {
    console.warn(`'state' should be a method that returns an object in ${filePath}`)

    const state = Object.assign({}, moduleData.state)
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData, { state: () => state })
  }
  return moduleData
}

function resolveStoreModules (moduleData, filename) {
  moduleData = moduleData.default || moduleData
  // Remove store src + extension (./foo/index.js -> foo/index)
  const namespace = filename.replace(/\.(js|mjs)$/, '')
  const namespaces = namespace.split('/')
  let moduleName = namespaces[namespaces.length - 1]
  const filePath = `store/${filename}`

  moduleData = moduleName === 'state'
    ? normalizeState(moduleData, filePath)
    : normalizeModule(moduleData, filePath)

  // If src is a known Vuex property
  if (VUEX_PROPERTIES.includes(moduleName)) {
    const property = moduleName
    const propertyStoreModule = getStoreModule(store, namespaces, { isProperty: true })

    // Replace state since it's a function
    mergeProperty(propertyStoreModule, moduleData, property)
    return
  }

  // If file is foo/index.js, it should be saved as foo
  const isIndexModule = (moduleName === 'index')
  if (isIndexModule) {
    namespaces.pop()
    moduleName = namespaces[namespaces.length - 1]
  }

  const storeModule = getStoreModule(store, namespaces)

  for (const property of VUEX_PROPERTIES) {
    mergeProperty(storeModule, moduleData[property], property)
  }

  if (moduleData.namespaced === false) {
    delete storeModule.namespaced
  }
}

function normalizeState (moduleData, filePath) {
  if (typeof moduleData !== 'function') {
    console.warn(`${filePath} should export a method that returns an object`)
    const state = Object.assign({}, moduleData)
    return () => state
  }
  return normalizeModule(moduleData, filePath)
}

function getStoreModule (storeModule, namespaces, { isProperty = false } = {}) {
  // If ./mutations.js
  if (!namespaces.length || (isProperty && namespaces.length === 1)) {
    return storeModule
  }

  const namespace = namespaces.shift()

  storeModule.modules[namespace] = storeModule.modules[namespace] || {}
  storeModule.modules[namespace].namespaced = true
  storeModule.modules[namespace].modules = storeModule.modules[namespace].modules || {}

  return getStoreModule(storeModule.modules[namespace], namespaces, { isProperty })
}

function mergeProperty (storeModule, moduleData, property) {
  if (!moduleData) {
    return
  }

  if (property === 'state') {
    storeModule.state = moduleData || storeModule.state
  } else {
    storeModule[property] = Object.assign({}, storeModule[property], moduleData)
  }
}
