const middleware = {}

middleware['adminauth'] = require('..\\middleware\\adminauth.js')
middleware['adminauth'] = middleware['adminauth'].default || middleware['adminauth']

middleware['auth'] = require('..\\middleware\\auth.js')
middleware['auth'] = middleware['auth'].default || middleware['auth']

middleware['authredirect'] = require('..\\middleware\\authredirect.js')
middleware['authredirect'] = middleware['authredirect'].default || middleware['authredirect']

middleware['autologin'] = require('..\\middleware\\autologin.js')
middleware['autologin'] = middleware['autologin'].default || middleware['autologin']

middleware['redirctdash'] = require('..\\middleware\\redirctdash.js')
middleware['redirctdash'] = middleware['redirctdash'].default || middleware['redirctdash']

export default middleware
