export const AdminAside = () => import('../..\\components\\admin\\AdminAside.vue' /* webpackChunkName: "components/admin-aside" */).then(c => wrapFunctional(c.default || c))
export const AdminChatAgentChatMessage = () => import('../..\\components\\admin\\chat\\AgentChatMessage.vue' /* webpackChunkName: "components/admin-chat-agent-chat-message" */).then(c => wrapFunctional(c.default || c))
export const AdminChatCustomerChatMessage = () => import('../..\\components\\admin\\chat\\CustomerChatMessage.vue' /* webpackChunkName: "components/admin-chat-customer-chat-message" */).then(c => wrapFunctional(c.default || c))
export const AdminChatSendMessageBox = () => import('../..\\components\\admin\\chat\\SendMessageBox.vue' /* webpackChunkName: "components/admin-chat-send-message-box" */).then(c => wrapFunctional(c.default || c))
export const ReusableDashInput = () => import('../..\\components\\reusable\\DashInput.vue' /* webpackChunkName: "components/reusable-dash-input" */).then(c => wrapFunctional(c.default || c))
export const ReusableMultiSelection = () => import('../..\\components\\reusable\\MultiSelection.vue' /* webpackChunkName: "components/reusable-multi-selection" */).then(c => wrapFunctional(c.default || c))
export const ReusableNotificationBox = () => import('../..\\components\\reusable\\NotificationBox.vue' /* webpackChunkName: "components/reusable-notification-box" */).then(c => wrapFunctional(c.default || c))
export const ReusableTextArea = () => import('../..\\components\\reusable\\ReusableTextArea.vue' /* webpackChunkName: "components/reusable-text-area" */).then(c => wrapFunctional(c.default || c))
export const ReusableSelectionList = () => import('../..\\components\\reusable\\SelectionList.vue' /* webpackChunkName: "components/reusable-selection-list" */).then(c => wrapFunctional(c.default || c))
export const ReusableUploadFileInput = () => import('../..\\components\\reusable\\UploadFileInput.vue' /* webpackChunkName: "components/reusable-upload-file-input" */).then(c => wrapFunctional(c.default || c))
export const LayoutAdminNavBar = () => import('../..\\components\\layout\\AdminNavBar.vue' /* webpackChunkName: "components/layout-admin-nav-bar" */).then(c => wrapFunctional(c.default || c))
export const LayoutFlashMessage = () => import('../..\\components\\layout\\FlashMessage.vue' /* webpackChunkName: "components/layout-flash-message" */).then(c => wrapFunctional(c.default || c))
export const LayoutSpinner = () => import('../..\\components\\layout\\Spinner.vue' /* webpackChunkName: "components/layout-spinner" */).then(c => wrapFunctional(c.default || c))
export const AdminReusableActiveModel = () => import('../..\\components\\admin\\reusable\\ActiveModel.vue' /* webpackChunkName: "components/admin-reusable-active-model" */).then(c => wrapFunctional(c.default || c))
export const AdminReusableCancelOrder = () => import('../..\\components\\admin\\reusable\\CancelOrder.vue' /* webpackChunkName: "components/admin-reusable-cancel-order" */).then(c => wrapFunctional(c.default || c))
export const AdminReusableDeleteModel = () => import('../..\\components\\admin\\reusable\\DeleteModel.vue' /* webpackChunkName: "components/admin-reusable-delete-model" */).then(c => wrapFunctional(c.default || c))
export const AdminReusablePaginationNav = () => import('../..\\components\\admin\\reusable\\PaginationNav.vue' /* webpackChunkName: "components/admin-reusable-pagination-nav" */).then(c => wrapFunctional(c.default || c))
export const AdminReusableProductNav = () => import('../..\\components\\admin\\reusable\\ProductNav.vue' /* webpackChunkName: "components/admin-reusable-product-nav" */).then(c => wrapFunctional(c.default || c))
export const AdminReusableReplaceItem = () => import('../..\\components\\admin\\reusable\\ReplaceItem.vue' /* webpackChunkName: "components/admin-reusable-replace-item" */).then(c => wrapFunctional(c.default || c))
export const AdminReusableUpdateOrderModel = () => import('../..\\components\\admin\\reusable\\UpdateOrderModel.vue' /* webpackChunkName: "components/admin-reusable-update-order-model" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesCategoryTable = () => import('../..\\components\\admin\\tables\\CategoryTable.vue' /* webpackChunkName: "components/admin-tables-category-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesComplainTable = () => import('../..\\components\\admin\\tables\\ComplainTable.vue' /* webpackChunkName: "components/admin-tables-complain-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesCouponTable = () => import('../..\\components\\admin\\tables\\CouponTable.vue' /* webpackChunkName: "components/admin-tables-coupon-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesCustomerTable = () => import('../..\\components\\admin\\tables\\CustomerTable.vue' /* webpackChunkName: "components/admin-tables-customer-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesItemTable = () => import('../..\\components\\admin\\tables\\ItemTable.vue' /* webpackChunkName: "components/admin-tables-item-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesOrderTable = () => import('../..\\components\\admin\\tables\\OrderTable.vue' /* webpackChunkName: "components/admin-tables-order-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesProductColorSizeTable = () => import('../..\\components\\admin\\tables\\ProductColorSizeTable.vue' /* webpackChunkName: "components/admin-tables-product-color-size-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesProductColorTable = () => import('../..\\components\\admin\\tables\\ProductColorTable.vue' /* webpackChunkName: "components/admin-tables-product-color-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesProductSizeTable = () => import('../..\\components\\admin\\tables\\ProductSizeTable.vue' /* webpackChunkName: "components/admin-tables-product-size-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesProductTable = () => import('../..\\components\\admin\\tables\\ProductTable.vue' /* webpackChunkName: "components/admin-tables-product-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesSingleCustomerTable = () => import('../..\\components\\admin\\tables\\SingleCustomerTable.vue' /* webpackChunkName: "components/admin-tables-single-customer-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesSliderTable = () => import('../..\\components\\admin\\tables\\SliderTable.vue' /* webpackChunkName: "components/admin-tables-slider-table" */).then(c => wrapFunctional(c.default || c))
export const AdminTablesSubcategoryTable = () => import('../..\\components\\admin\\tables\\SubcategoryTable.vue' /* webpackChunkName: "components/admin-tables-subcategory-table" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
