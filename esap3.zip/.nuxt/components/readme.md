# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AdminAside>` | `<admin-aside>` (components/admin/AdminAside.vue)
- `<AdminChatAgentChatMessage>` | `<admin-chat-agent-chat-message>` (components/admin/chat/AgentChatMessage.vue)
- `<AdminChatCustomerChatMessage>` | `<admin-chat-customer-chat-message>` (components/admin/chat/CustomerChatMessage.vue)
- `<AdminChatSendMessageBox>` | `<admin-chat-send-message-box>` (components/admin/chat/SendMessageBox.vue)
- `<ReusableDashInput>` | `<reusable-dash-input>` (components/reusable/DashInput.vue)
- `<ReusableMultiSelection>` | `<reusable-multi-selection>` (components/reusable/MultiSelection.vue)
- `<ReusableNotificationBox>` | `<reusable-notification-box>` (components/reusable/NotificationBox.vue)
- `<ReusableTextArea>` | `<reusable-text-area>` (components/reusable/ReusableTextArea.vue)
- `<ReusableSelectionList>` | `<reusable-selection-list>` (components/reusable/SelectionList.vue)
- `<ReusableUploadFileInput>` | `<reusable-upload-file-input>` (components/reusable/UploadFileInput.vue)
- `<LayoutAdminNavBar>` | `<layout-admin-nav-bar>` (components/layout/AdminNavBar.vue)
- `<LayoutFlashMessage>` | `<layout-flash-message>` (components/layout/FlashMessage.vue)
- `<LayoutSpinner>` | `<layout-spinner>` (components/layout/Spinner.vue)
- `<AdminReusableActiveModel>` | `<admin-reusable-active-model>` (components/admin/reusable/ActiveModel.vue)
- `<AdminReusableCancelOrder>` | `<admin-reusable-cancel-order>` (components/admin/reusable/CancelOrder.vue)
- `<AdminReusableDeleteModel>` | `<admin-reusable-delete-model>` (components/admin/reusable/DeleteModel.vue)
- `<AdminReusablePaginationNav>` | `<admin-reusable-pagination-nav>` (components/admin/reusable/PaginationNav.vue)
- `<AdminReusableProductNav>` | `<admin-reusable-product-nav>` (components/admin/reusable/ProductNav.vue)
- `<AdminReusableReplaceItem>` | `<admin-reusable-replace-item>` (components/admin/reusable/ReplaceItem.vue)
- `<AdminReusableUpdateOrderModel>` | `<admin-reusable-update-order-model>` (components/admin/reusable/UpdateOrderModel.vue)
- `<AdminTablesCategoryTable>` | `<admin-tables-category-table>` (components/admin/tables/CategoryTable.vue)
- `<AdminTablesComplainTable>` | `<admin-tables-complain-table>` (components/admin/tables/ComplainTable.vue)
- `<AdminTablesCouponTable>` | `<admin-tables-coupon-table>` (components/admin/tables/CouponTable.vue)
- `<AdminTablesCustomerTable>` | `<admin-tables-customer-table>` (components/admin/tables/CustomerTable.vue)
- `<AdminTablesItemTable>` | `<admin-tables-item-table>` (components/admin/tables/ItemTable.vue)
- `<AdminTablesOrderTable>` | `<admin-tables-order-table>` (components/admin/tables/OrderTable.vue)
- `<AdminTablesProductColorSizeTable>` | `<admin-tables-product-color-size-table>` (components/admin/tables/ProductColorSizeTable.vue)
- `<AdminTablesProductColorTable>` | `<admin-tables-product-color-table>` (components/admin/tables/ProductColorTable.vue)
- `<AdminTablesProductSizeTable>` | `<admin-tables-product-size-table>` (components/admin/tables/ProductSizeTable.vue)
- `<AdminTablesProductTable>` | `<admin-tables-product-table>` (components/admin/tables/ProductTable.vue)
- `<AdminTablesSingleCustomerTable>` | `<admin-tables-single-customer-table>` (components/admin/tables/SingleCustomerTable.vue)
- `<AdminTablesSliderTable>` | `<admin-tables-slider-table>` (components/admin/tables/SliderTable.vue)
- `<AdminTablesSubcategoryTable>` | `<admin-tables-subcategory-table>` (components/admin/tables/SubcategoryTable.vue)
