import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _27ab0b59 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _203e06d8 = () => interopDefault(import('..\\pages\\admin\\dashboard\\index.vue' /* webpackChunkName: "pages/admin/dashboard/index" */))
const _453f169a = () => interopDefault(import('..\\pages\\admin\\order\\index.vue' /* webpackChunkName: "pages/admin/order/index" */))
const _b25525f0 = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _984d1c36 = () => interopDefault(import('..\\pages\\admin\\category\\add\\index.vue' /* webpackChunkName: "pages/admin/category/add/index" */))
const _2fc6ccd0 = () => interopDefault(import('..\\pages\\admin\\category\\list\\index.vue' /* webpackChunkName: "pages/admin/category/list/index" */))
const _f926d6e6 = () => interopDefault(import('..\\pages\\admin\\coupon\\add\\index.vue' /* webpackChunkName: "pages/admin/coupon/add/index" */))
const _f433e992 = () => interopDefault(import('..\\pages\\admin\\coupon\\assign\\index.vue' /* webpackChunkName: "pages/admin/coupon/assign/index" */))
const _5297ff28 = () => interopDefault(import('..\\pages\\admin\\coupon\\list\\index.vue' /* webpackChunkName: "pages/admin/coupon/list/index" */))
const _51bbe49a = () => interopDefault(import('..\\pages\\admin\\product\\add\\index.vue' /* webpackChunkName: "pages/admin/product/add/index" */))
const _4e32b0bb = () => interopDefault(import('..\\pages\\admin\\product\\list\\index.vue' /* webpackChunkName: "pages/admin/product/list/index" */))
const _49414170 = () => interopDefault(import('..\\pages\\admin\\slider\\add\\index.vue' /* webpackChunkName: "pages/admin/slider/add/index" */))
const _0e02e866 = () => interopDefault(import('..\\pages\\admin\\slider\\list\\index.vue' /* webpackChunkName: "pages/admin/slider/list/index" */))
const _796ac3e9 = () => interopDefault(import('..\\pages\\admin\\subcategory\\add\\index.vue' /* webpackChunkName: "pages/admin/subcategory/add/index" */))
const _1c5fbb4c = () => interopDefault(import('..\\pages\\admin\\subcategory\\list\\index.vue' /* webpackChunkName: "pages/admin/subcategory/list/index" */))
const _9884f03a = () => interopDefault(import('..\\pages\\admin\\user\\customer\\index.vue' /* webpackChunkName: "pages/admin/user/customer/index" */))
const _3c9c8ea0 = () => interopDefault(import('..\\pages\\admin\\category\\_id\\edit.vue' /* webpackChunkName: "pages/admin/category/_id/edit" */))
const _224676f8 = () => interopDefault(import('..\\pages\\admin\\coupon\\_id\\edit.vue' /* webpackChunkName: "pages/admin/coupon/_id/edit" */))
const _10ed1850 = () => interopDefault(import('..\\pages\\admin\\product\\_id\\color\\index.vue' /* webpackChunkName: "pages/admin/product/_id/color/index" */))
const _52dbaad6 = () => interopDefault(import('..\\pages\\admin\\product\\_id\\color-size\\index.vue' /* webpackChunkName: "pages/admin/product/_id/color-size/index" */))
const _e93a2e52 = () => interopDefault(import('..\\pages\\admin\\product\\_id\\edit\\index.vue' /* webpackChunkName: "pages/admin/product/_id/edit/index" */))
const _46dab1e9 = () => interopDefault(import('..\\pages\\admin\\product\\_id\\images\\index.vue' /* webpackChunkName: "pages/admin/product/_id/images/index" */))
const _42026680 = () => interopDefault(import('..\\pages\\admin\\product\\_id\\size\\index.vue' /* webpackChunkName: "pages/admin/product/_id/size/index" */))
const _8901adf6 = () => interopDefault(import('..\\pages\\admin\\slider\\_id\\edit\\index.vue' /* webpackChunkName: "pages/admin/slider/_id/edit/index" */))
const _a35227c8 = () => interopDefault(import('..\\pages\\admin\\subcategory\\_id\\edit.vue' /* webpackChunkName: "pages/admin/subcategory/_id/edit" */))
const _6b6eeef8 = () => interopDefault(import('..\\pages\\admin\\product\\_id\\color-size\\list\\index.vue' /* webpackChunkName: "pages/admin/product/_id/color-size/list/index" */))
const _549a4e1c = () => interopDefault(import('..\\pages\\admin\\product\\_id\\color\\list\\index.vue' /* webpackChunkName: "pages/admin/product/_id/color/list/index" */))
const _3440c322 = () => interopDefault(import('..\\pages\\admin\\product\\_id\\size\\list\\index.vue' /* webpackChunkName: "pages/admin/product/_id/size/list/index" */))
const _0ecad66f = () => interopDefault(import('..\\pages\\admin\\product\\_id\\color\\color_id\\edit\\index.vue' /* webpackChunkName: "pages/admin/product/_id/color/color_id/edit/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/ar",
    component: _27ab0b59,
    name: "index___ar"
  }, {
    path: "/admin/dashboard",
    component: _203e06d8,
    name: "admin-dashboard___en"
  }, {
    path: "/admin/order",
    component: _453f169a,
    name: "admin-order___en"
  }, {
    path: "/auth/login",
    component: _b25525f0,
    name: "auth-login___en"
  }, {
    path: "/admin/category/add",
    component: _984d1c36,
    name: "admin-category-add___en"
  }, {
    path: "/admin/category/list",
    component: _2fc6ccd0,
    name: "admin-category-list___en"
  }, {
    path: "/admin/coupon/add",
    component: _f926d6e6,
    name: "admin-coupon-add___en"
  }, {
    path: "/admin/coupon/assign",
    component: _f433e992,
    name: "admin-coupon-assign___en"
  }, {
    path: "/admin/coupon/list",
    component: _5297ff28,
    name: "admin-coupon-list___en"
  }, {
    path: "/admin/product/add",
    component: _51bbe49a,
    name: "admin-product-add___en"
  }, {
    path: "/admin/product/list",
    component: _4e32b0bb,
    name: "admin-product-list___en"
  }, {
    path: "/admin/slider/add",
    component: _49414170,
    name: "admin-slider-add___en"
  }, {
    path: "/admin/slider/list",
    component: _0e02e866,
    name: "admin-slider-list___en"
  }, {
    path: "/admin/subcategory/add",
    component: _796ac3e9,
    name: "admin-subcategory-add___en"
  }, {
    path: "/admin/subcategory/list",
    component: _1c5fbb4c,
    name: "admin-subcategory-list___en"
  }, {
    path: "/admin/user/customer",
    component: _9884f03a,
    name: "admin-user-customer___en"
  }, {
    path: "/ar/admin/dashboard",
    component: _203e06d8,
    name: "admin-dashboard___ar"
  }, {
    path: "/ar/admin/order",
    component: _453f169a,
    name: "admin-order___ar"
  }, {
    path: "/ar/auth/login",
    component: _b25525f0,
    name: "auth-login___ar"
  }, {
    path: "/ar/admin/category/add",
    component: _984d1c36,
    name: "admin-category-add___ar"
  }, {
    path: "/ar/admin/category/list",
    component: _2fc6ccd0,
    name: "admin-category-list___ar"
  }, {
    path: "/ar/admin/coupon/add",
    component: _f926d6e6,
    name: "admin-coupon-add___ar"
  }, {
    path: "/ar/admin/coupon/assign",
    component: _f433e992,
    name: "admin-coupon-assign___ar"
  }, {
    path: "/ar/admin/coupon/list",
    component: _5297ff28,
    name: "admin-coupon-list___ar"
  }, {
    path: "/ar/admin/product/add",
    component: _51bbe49a,
    name: "admin-product-add___ar"
  }, {
    path: "/ar/admin/product/list",
    component: _4e32b0bb,
    name: "admin-product-list___ar"
  }, {
    path: "/ar/admin/slider/add",
    component: _49414170,
    name: "admin-slider-add___ar"
  }, {
    path: "/ar/admin/slider/list",
    component: _0e02e866,
    name: "admin-slider-list___ar"
  }, {
    path: "/ar/admin/subcategory/add",
    component: _796ac3e9,
    name: "admin-subcategory-add___ar"
  }, {
    path: "/ar/admin/subcategory/list",
    component: _1c5fbb4c,
    name: "admin-subcategory-list___ar"
  }, {
    path: "/ar/admin/user/customer",
    component: _9884f03a,
    name: "admin-user-customer___ar"
  }, {
    path: "/",
    component: _27ab0b59,
    name: "index___en"
  }, {
    path: "/ar/admin/category/:id?/edit",
    component: _3c9c8ea0,
    name: "admin-category-id-edit___ar"
  }, {
    path: "/ar/admin/coupon/:id?/edit",
    component: _224676f8,
    name: "admin-coupon-id-edit___ar"
  }, {
    path: "/ar/admin/product/:id?/color",
    component: _10ed1850,
    name: "admin-product-id-color___ar"
  }, {
    path: "/ar/admin/product/:id?/color-size",
    component: _52dbaad6,
    name: "admin-product-id-color-size___ar"
  }, {
    path: "/ar/admin/product/:id?/edit",
    component: _e93a2e52,
    name: "admin-product-id-edit___ar"
  }, {
    path: "/ar/admin/product/:id?/images",
    component: _46dab1e9,
    name: "admin-product-id-images___ar"
  }, {
    path: "/ar/admin/product/:id?/size",
    component: _42026680,
    name: "admin-product-id-size___ar"
  }, {
    path: "/ar/admin/slider/:id?/edit",
    component: _8901adf6,
    name: "admin-slider-id-edit___ar"
  }, {
    path: "/ar/admin/subcategory/:id?/edit",
    component: _a35227c8,
    name: "admin-subcategory-id-edit___ar"
  }, {
    path: "/ar/admin/product/:id?/color-size/list",
    component: _6b6eeef8,
    name: "admin-product-id-color-size-list___ar"
  }, {
    path: "/ar/admin/product/:id?/color/list",
    component: _549a4e1c,
    name: "admin-product-id-color-list___ar"
  }, {
    path: "/ar/admin/product/:id?/size/list",
    component: _3440c322,
    name: "admin-product-id-size-list___ar"
  }, {
    path: "/ar/admin/product/:id?/color/color_id/edit",
    component: _0ecad66f,
    name: "admin-product-id-color-color_id-edit___ar"
  }, {
    path: "/admin/category/:id?/edit",
    component: _3c9c8ea0,
    name: "admin-category-id-edit___en"
  }, {
    path: "/admin/coupon/:id?/edit",
    component: _224676f8,
    name: "admin-coupon-id-edit___en"
  }, {
    path: "/admin/product/:id?/color",
    component: _10ed1850,
    name: "admin-product-id-color___en"
  }, {
    path: "/admin/product/:id?/color-size",
    component: _52dbaad6,
    name: "admin-product-id-color-size___en"
  }, {
    path: "/admin/product/:id?/edit",
    component: _e93a2e52,
    name: "admin-product-id-edit___en"
  }, {
    path: "/admin/product/:id?/images",
    component: _46dab1e9,
    name: "admin-product-id-images___en"
  }, {
    path: "/admin/product/:id?/size",
    component: _42026680,
    name: "admin-product-id-size___en"
  }, {
    path: "/admin/slider/:id?/edit",
    component: _8901adf6,
    name: "admin-slider-id-edit___en"
  }, {
    path: "/admin/subcategory/:id?/edit",
    component: _a35227c8,
    name: "admin-subcategory-id-edit___en"
  }, {
    path: "/admin/product/:id?/color-size/list",
    component: _6b6eeef8,
    name: "admin-product-id-color-size-list___en"
  }, {
    path: "/admin/product/:id?/color/list",
    component: _549a4e1c,
    name: "admin-product-id-color-list___en"
  }, {
    path: "/admin/product/:id?/size/list",
    component: _3440c322,
    name: "admin-product-id-size-list___en"
  }, {
    path: "/admin/product/:id?/color/color_id/edit",
    component: _0ecad66f,
    name: "admin-product-id-color-color_id-edit___en"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
