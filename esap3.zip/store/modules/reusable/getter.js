export default {
  loading(state) {
    return state.loading
  },
  message(state) {
    return state.message
  },
  success(state) {
    return state.success
  },
  errArr(state) {
    return state.errArr
  },


}
