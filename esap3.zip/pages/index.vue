<template>

</template>

<script>
export default {
  middleware: ['redirctdash',],
}
</script>
