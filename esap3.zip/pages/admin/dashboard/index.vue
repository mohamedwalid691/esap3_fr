<template>
  <div class="admin-content col-10 no-gutters"></div>
</template>

<script>


export default {
  components: {

  },

  layout: 'admin',
}
</script>

<style></style>
